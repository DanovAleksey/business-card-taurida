import logInfo from './logInfo.js';
import * as tictac from './tictac.js'

logInfo();


const cells = document.querySelectorAll(".cell");
const message = document.querySelector(".message");
const button = document.querySelector(".button");
const table = document.querySelector(".table");
const body = document.querySelector("body");

cells.forEach((c) => {
    c.addEventListener("click", onCellClick);
});
button.addEventListener("click", onNewGameCLick);

function onCellClick(e) {
    let cell = e.target,
      index = cell.dataset.cell;
    if(!cell.classList.contains("cell-used")) {
        let player = tictac.getPlayer();
        cell.innerText = player;
        cell.classList.add("cell-used");
        //console.log(index, player);

        
        let win = tictac.check(index);
        if (win) {
            message.innerText = 'Winner: ' + win + ' (steps: ' + tictac.steps.length + ')';

            //lock all
            cells.forEach((c) => {
                c.classList.add("cell-used");
            });
            
            body.classList.add("body-animation");
        } else {
            tictac.setPlayer(player === "x" ? "o" : "x");
        }
    }
}

function onNewGameCLick(e) {
    //console.log("NewGame");
    tictac.newGame();
    //unlock all
    cells.forEach((c) => {
        c.classList.remove("cell-used");
        c.innerHTML = "";
    });
    message.innerText = "Game";
    for(var i = table.rows.length - 1; i > 0; i--)
    {
        table.deleteRow(i);
    }
    body.classList.remove("body-animation");
    tableDraw();
}

function tableDraw() {
    const tableArr = JSON.parse(localStorage.getItem('history'));
    if(tableArr) {
        for (let row of tableArr) {
            table.insertRow();
            let lastStep = row[row.length - 1];
            let newCell = table.rows[table.rows.length - 1].insertCell();
            newCell.textContent = lastStep.player;
            let newCell2 = table.rows[table.rows.length - 1].insertCell();
            newCell2.textContent = row.length;
        }
    }
}
tableDraw();