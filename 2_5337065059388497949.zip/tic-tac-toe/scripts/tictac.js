let player = "x";
export function getPlayer() {
    return player;
}
export function setPlayer(value) {
    player = value;
}

const winCombo = [
  [0, 1, 2],
  [3, 4, 5],
  [6, 7, 8],

  [0, 3, 6],
  [1, 4, 7],
  [2, 5, 8],

  [0, 4, 8],
  [2, 4, 6],
];

export let steps = [];

export function check (index) {
    let step = {
        "index": index,
        "player": player
    };
    steps.push(step);
    //console.log('steps: ', steps);

    for (let i = 0; i < winCombo.length; i++) {
        const variant = winCombo[i];
        let p = '';
        for (let ii = 0; ii < variant.length; ii++) {
            const element = variant[ii];
            
            for (let j = 0; j < steps.length; j++) {
                const step = steps[j];
                
                if (step.index == element) {
                  p += step.player;
                }
            }
        }
        
        if (p === "xxx" || p === "ooo") {
            //alert('winner: '+ p);
            let history = localStorage.getItem("history");
            let res = "";
            if (history) {
                let historyArray = JSON.parse(history);
                //max 10 results
                if(historyArray.length > 10) {
                    historyArray.pop();
                }
                historyArray.unshift(steps);
                res = JSON.stringify(historyArray);
            } else {
                //new array of history
                res = ['[', JSON.stringify(steps),']'].join('');
            }
            localStorage.setItem("history", res);
            
            //console.log(JSON.parse(localStorage.getItem("history")));

            return p[0];
        }
    }
}

export function newGame() {
    //clear steps
    while(steps.length > 0) {
        steps.pop();
    }
    player = "x";
}
